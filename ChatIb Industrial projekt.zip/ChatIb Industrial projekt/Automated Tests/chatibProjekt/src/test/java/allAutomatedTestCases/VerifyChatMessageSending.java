package allAutomatedTestCases;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class VerifyChatMessageSending {
	WebDriver driver = null;

    @BeforeTest
    public void setUpTest() {
        // Set WebDriver (Before test)
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized"); // Maximize the browser window
        driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.manage().timeouts().pageLoadTimeout(25, TimeUnit.SECONDS);
    }

    @Test(priority = 1)
    public void testLogin() throws InterruptedException {
        // Go to the chatib URL
        driver.get("https://www.chatib.us/");

        // Click on login
        driver.findElement(By.className("user-login")).click();
        driver.switchTo().frame("gdpr-consent-notice");

        driver.findElement(By.id("save")).click();

        // Type an email
        driver.findElement(By.id("email")).sendKeys("yogeshkale747@gmail.com");

        // Type a password
        driver.findElement(By.id("password_1")).sendKeys("!Rinzzler97"); // Updated the password locator

        // Tick the reCAPTCHA box (you may need to improve this locator)
        System.out.println("before switching frame");
        Thread.sleep(5000);
        driver.switchTo().defaultContent();
        System.out.println("lin56");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(
                By.xpath("//iframe[starts-with(@name, 'a-') and starts-with(@src, 'https://www.google.com/recaptcha')]")));

        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//div[@class='recaptcha-checkbox-border']"))).click();
        System.out.println("switched frame working");

        System.out.println("click the check box");

        // Submit Login
        driver.findElement(By.cssSelector("input[value='LOGIN']")).click();
    }
    
        @Test (priority = 2)
        public void testChatMessageSending() {
            // Locate the sender and send Text 
           
            driver.findElement(By.className("user_name_text")).click();
            driver.findElement(By.className("contentDiv")).sendKeys("Hello, Sachin how are you?");

            

}
        @AfterTest
        public void tearDownTest() {
            // Close the WebDriver after the test
            driver.quit();
            driver.close();
}
}